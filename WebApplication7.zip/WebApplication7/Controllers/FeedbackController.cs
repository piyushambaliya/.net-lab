﻿using Microsoft.AspNetCore.Mvc;
using WebApplication7.Models;

namespace WebApplication7.Controllers
{
    public class FeedbackController : Controller
    {
        // In-memory storage (lab ke liye database ki zaroorat nahi)
        private static readonly List<Feedback> _feedbacks = new();
        private static int _nextId = 1;

        // GET: /Feedback?search=abc&category=Service
        public IActionResult Index(string? search, string? category)
        {
            var data = _feedbacks.AsEnumerable();

            if (!string.IsNullOrWhiteSpace(search))
            {
                data = data.Where(f =>
                    f.Name.Contains(search, StringComparison.OrdinalIgnoreCase) ||
                    f.Comments.Contains(search, StringComparison.OrdinalIgnoreCase));
            }

            if (!string.IsNullOrWhiteSpace(category))
            {
                data = data.Where(f => f.Category == category);
            }

            ViewBag.Search = search;
            ViewBag.Category = category;

            return View(data.OrderByDescending(f => f.SubmittedOn).ToList());
        }

        // GET: /Feedback/Create
        [HttpGet]
        public IActionResult Create()
        {
            return View(new Feedback());
        }

        // POST: /Feedback/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Feedback model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);   // errors ke saath form dobara dikhao
            }

            model.Id = _nextId++;
            model.SubmittedOn = DateTime.Now;
            _feedbacks.Add(model);

            TempData["Message"] = "Thank you! Your feedback was submitted.";
            return RedirectToAction(nameof(Index));
        }

        // GET: /Feedback/Edit/3
        [HttpGet]
        public IActionResult Edit(int id)
        {
            var item = _feedbacks.FirstOrDefault(f => f.Id == id);
            if (item == null) return NotFound();
            return View(item);
        }

        // POST: /Feedback/Edit
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Feedback model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var item = _feedbacks.FirstOrDefault(f => f.Id == model.Id);
            if (item == null) return NotFound();

            item.Name = model.Name;
            item.Email = model.Email;
            item.Category = model.Category;
            item.Rating = model.Rating;
            item.Comments = model.Comments;

            TempData["Message"] = "Feedback updated successfully.";
            return RedirectToAction(nameof(Index));
        }

        // POST: /Feedback/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Delete(int id)
        {
            var item = _feedbacks.FirstOrDefault(f => f.Id == id);
            if (item != null)
            {
                _feedbacks.Remove(item);
                TempData["Message"] = "Feedback deleted.";
            }
            return RedirectToAction(nameof(Index));
        }
    }
}