﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication7.Models
{
    public class Feedback
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Name is required")]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "Name must be 3 to 50 characters")]
        [Display(Name = "Full Name")]
        public string Name { get; set; } = string.Empty;

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Enter a valid email address")]
        public string Email { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please select a category")]
        public string Category { get; set; } = string.Empty;

        [Range(1, 5, ErrorMessage = "Please select a rating between 1 and 5")]
        public int Rating { get; set; }

        [Required(ErrorMessage = "Comments are required")]
        [StringLength(500, MinimumLength = 10, ErrorMessage = "Comments must be 10 to 500 characters")]
        [DataType(DataType.MultilineText)]
        public string Comments { get; set; } = string.Empty;

        [DataType(DataType.Date)]
        [Display(Name = "Submitted On")]
        public DateTime SubmittedOn { get; set; } = DateTime.Now;
    }
}