﻿document.addEventListener('DOMContentLoaded', function () {

    // ---------- Dark mode toggle ----------
    var btn = document.getElementById('themeToggle');
    var root = document.documentElement;

    function setIcon() {
        if (!btn) return;
        var dark = root.getAttribute('data-bs-theme') === 'dark';
        btn.innerHTML = dark ? '<i class="bi bi-sun"></i>' : '<i class="bi bi-moon-stars"></i>';
    }

    if (btn) {
        setIcon();
        btn.addEventListener('click', function () {
            var next = root.getAttribute('data-bs-theme') === 'dark' ? 'light' : 'dark';
            root.setAttribute('data-bs-theme', next);
            try { localStorage.setItem('theme', next); } catch (e) { }
            setIcon();
        });
    }

    // ---------- Comments character counter ----------
    var box = document.getElementById('Comments');
    var counter = document.getElementById('charCount');
    if (box && counter) {
        counter.textContent = box.value.length;
        box.addEventListener('input', function () {
            counter.textContent = box.value.length;
        });
    }
});